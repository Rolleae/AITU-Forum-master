﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;


namespace AITU_forum1.Core.Dtos
{
    public class PostDto
    {
        public string Name { get; set; }
        public string Description { get; set; }
        public string Text { get; set; }
    }
}
