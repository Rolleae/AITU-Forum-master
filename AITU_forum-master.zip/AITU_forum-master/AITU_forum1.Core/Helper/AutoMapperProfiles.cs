﻿using AITU_forum1.Core.Dtos;
using AITU_forum1.Core.Models;
using AutoMapper;
using System;
using System.Collections.Generic;
using System.Text;

namespace AITU_forum1.Core.Helper
{
    public class AutoMapperProfiles : Profile
    {
        public AutoMapperProfiles()
        {
            CreateMap<Post, PostDto>();

            CreateMap<User, UserDto>();
        }
    }
}
