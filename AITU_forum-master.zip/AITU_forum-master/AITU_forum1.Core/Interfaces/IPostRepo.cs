﻿using AITU_forum1.Core.Dtos;
using AITU_forum1.Core.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace AITU_forum1.Core.Repositories.Interfaces
{
    public interface IPostRepo
    {
        Task<IEnumerable<Post>> GetPosts();
        Task<bool> AddPost(Post post);
        Task<bool> UpdatePost(Post post);
        Task<bool> DeletePost(Guid id);
        Task<Post> GetPostById(Guid id);
    }
}
