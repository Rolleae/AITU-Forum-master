﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace AITU_forum1.Core.Models
{
    public class Role
    {
        public const string LeaderOfGroup = "LeaderOfGroup";
        public const string SimpleStudent = "SimpleStudent";
    }
}
