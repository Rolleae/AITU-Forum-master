﻿using AITU_forum1.Infostructure.Data;
using AITU_forum1.Core.Dtos;
using AITU_forum1.Core.Models;
using AITU_forum1.Core.Repositories.Interfaces;
using Microsoft.EntityFrameworkCore;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace AITU_forum1.Repositories
{
    public class PostRepo : IPostRepo
    {
        private readonly DataContext _context;

        public PostRepo(DataContext context)
        {
            _context = context;
        }

        public async Task<bool> AddPost(Post post)
        {
            _context.PostList.Add(post);
            return await _context.SaveChangesAsync() > 0;
        }

        public async Task<bool> DeletePost(Guid id)
        {
            Post post = _context.PostList.FirstOrDefault(x => x.Id == id);
            if(post != null)    
            {
                _context.PostList.Remove(post);
                return await _context.SaveChangesAsync() > 0;
                
            }
            return false;
        }

        public async Task<Post> GetPostById(Guid id)
        {
            return await _context.PostList.FirstOrDefaultAsync(x => x.Id == id);
        }

        public async Task<IEnumerable<Post>> GetPosts()
        {
            return await _context.PostList.OrderBy(x => x.Name).ToListAsync();
        }

        public async Task<bool> UpdatePost(Post post)
        {
            return true;
        }


    }
}
