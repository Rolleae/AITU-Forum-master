﻿using AITU_forum1.Infostructure.Data;
using AITU_forum1.Core.Models;
using AITU_forum1.Core.Repositories.Interfaces;
using Microsoft.EntityFrameworkCore;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace AITU_forum1.Repositories
{
    public class UserRepo : IUserRepo
    {
        private DataContext _context;

        public UserRepo(DataContext context)
        {
            _context = context;
        }

        public async Task<bool> AddUser(User user)
        {
            _context.UserList.Add(user);
            return await _context.SaveChangesAsync() > 0;
        }

        public async Task<bool> DeleteUser(Guid id)
        {
            var user = _context.UserList.FirstOrDefault(x => x.Id == id);
            if (user != null)
            {
                _context.UserList.Remove(user);
                _context.SaveChanges();
                return await _context.SaveChangesAsync() > 0;
            }
            return false;
        }

        public async Task<User> GetUserById(Guid id)
        {
            return await _context.UserList.FirstOrDefaultAsync(x => x.Id == id);
        }



        public async Task<IEnumerable<User>> GetUsers()
        {
            return await _context.UserList.OrderBy(x => x.Name).ToListAsync();
        }

        public async Task<bool> UpdateUser(User user)
        {
            return true;
        }
    }
}
