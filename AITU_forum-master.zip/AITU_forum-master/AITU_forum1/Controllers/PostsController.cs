﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using AITU_forum1.Core.Dtos;
using AITU_forum1.Core.Models;
using AITU_forum1.Core.Repositories.Interfaces;
using AutoMapper;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;

namespace AITU_forum1.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class PostsController : ControllerBase
    {
        private readonly IPostRepo _postRepo;
        private readonly IMapper _mapper;

        public PostsController(IPostRepo postRepo, IMapper mapper)
        {
            _postRepo = postRepo;
            _mapper = mapper;
        }
        [Authorize(Roles = "LeaderOfGroup,SimpleStudent")]
        [HttpGet]
        public async Task<ActionResult<ICollection<PostDto>>> GetPosts()
        {
            IEnumerable<Post> innerPosts = await _postRepo.GetPosts();
            /*ICollection<PostDto> posts = new LinkedList<PostDto>();*/
            var postsToSend = _mapper.Map<LinkedList<PostDto>>(innerPosts);


/*            foreach (Post p in innerPosts)
            {
                posts.Add(new PostDto()
                {
                    Name = p.Name,
                    Description = p.Description,
                    Text = p.Text
                });
            }*/
            return Ok(postsToSend);

        }
    
        [Authorize(Roles = "LeaderOfGroup,SimpleStudent")]
        [HttpPost("add")]
        public async Task<ActionResult> AddPost(PostDto post)
        {
            Post p = new Post(post);
            if (await _postRepo.AddPost(p))
            {
                return Ok(p);
            }
            return BadRequest("Some problem occured during adding the new post");
        }
        [Authorize(Roles = "LeaderOfGroup")]
        [HttpDelete("{id}")]
        public async Task<ActionResult> DeletePost(Guid id)
        {
            if (await _postRepo.DeletePost(id))
            {
                return Ok("Post was deleted");
            }
            return BadRequest("Some problem occured during deletion the post");
        }
        [HttpGet("{id}")]
        public async Task<ActionResult> GetPostById(Guid id)
        {
            if (await _postRepo.GetPostById(id) != null)
            {
                return Ok(_postRepo.GetPostById(id));
            }
            return BadRequest("No post was found!");
        }
        [HttpPost("update")]
        public async Task<ActionResult> UpdatePost(Post post)
        {
            if (await _postRepo.UpdatePost(post))
            {
                return Ok("Post has been updated");
            }
            return BadRequest("Problem with updating the post");
        }
        
    }
}
