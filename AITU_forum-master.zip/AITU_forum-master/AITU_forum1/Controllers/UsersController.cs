﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using AITU_forum1.Core.Dtos;
using AITU_forum1.Core.Models;
using AITU_forum1.Core.Repositories.Interfaces;
using AutoMapper;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;

namespace AITU_forum1.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class UsersController : ControllerBase
    {
        private readonly IUserRepo _userRepo;
        private readonly IMapper _mapper;

        public UsersController(IUserRepo userRepo, IMapper mapper)
        {
            _userRepo = userRepo;
            _mapper = mapper;
        }

        [Authorize(Roles = "LeaderOfGroup")] 
        [HttpGet]
        public async Task<ActionResult<ICollection<UserDto>>> GetUsers()
        {
            IEnumerable<User> innerStudents = await _userRepo.GetUsers();
            /*ICollection<UserDto> users = new LinkedList<UserDto>();*/
            var usersToSend = _mapper.Map<LinkedList<User>>(innerStudents);


/*            foreach (User s in innerStudents)
            {
                users.Add(new UserDto()
                {
                    Name = s.Name,
                    Surname = s.Surname,
                    Birthday = s.Birthday,
                    GroupId = s.GroupId
                });
            }*/
            return Ok(usersToSend);
        }
        [Authorize(Roles = "LeaderOfGroup")]
        [HttpGet("{id}")]
        public async Task<ActionResult> GetUserById(Guid id)
        {
            if (await _userRepo.GetUserById(id) != null)
            {
                return Ok(await _userRepo.GetUserById(id));
            }
            return BadRequest("No post was found!");
        }
        [HttpPost("update")]
        public async Task<ActionResult> UpdatePost(User user)
        {
            if (await _userRepo.UpdateUser(user))
            {
                return Ok("User has been updated");
            }
            return BadRequest("Problem with updating the user");
        }

        [HttpPost]
        public async Task<ActionResult> AddUser(UserDto user)
        {
            User us = new User(user);

            if(await _userRepo.AddUser(us))
            {
                return Ok("A new user has been created");
            }
            return BadRequest("Some problem occured");
        }
        [Authorize(Roles = "LeaderOfGroup")]
        [HttpPost("delete")]
        public async Task<ActionResult> DeleteUser(Guid id)
        {
            if (await _userRepo.DeleteUser(id))
            {
                return Ok("User was deleted");
            }
            return BadRequest("Some problem occured during deletion of the user");
        }
    }
}
